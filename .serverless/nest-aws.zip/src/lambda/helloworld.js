"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async (event, context, callback) => {
    try {
        const response = {
            statusCode: 200,
            body: `Hello`,
        };
        callback(null, JSON.stringify(response));
    }
    catch (error) {
        return {
            statusCode: 500,
            body: error
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=helloworld.js.map